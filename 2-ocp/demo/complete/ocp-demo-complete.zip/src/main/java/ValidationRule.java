public interface ValidationRule {
    ValidationResult check(FlightPlan fp);
}
