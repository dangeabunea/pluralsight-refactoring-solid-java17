public record Coordinate(int x, int y){

}
