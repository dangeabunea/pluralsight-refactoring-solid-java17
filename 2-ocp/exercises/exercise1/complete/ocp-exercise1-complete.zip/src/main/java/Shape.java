public abstract class Shape {
    public abstract boolean isPointInsideArea(int x, int y);
}
