public abstract class Shape {
}
