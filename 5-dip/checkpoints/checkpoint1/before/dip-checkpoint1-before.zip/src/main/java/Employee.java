public record Employee(String name, int income){

}