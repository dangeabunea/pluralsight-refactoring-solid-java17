import java.util.List;

public interface EmployeeApi {
    List<Employee> findAll();
}
