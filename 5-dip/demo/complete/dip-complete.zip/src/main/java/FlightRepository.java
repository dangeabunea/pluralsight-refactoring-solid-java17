import java.util.List;

public interface FlightRepository {
    List<Flight> findAll();
}
