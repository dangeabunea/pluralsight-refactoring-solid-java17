public class Feature extends Task {
    public Feature(String description, int estimationInDays) {
        super(description, estimationInDays);
    }
}
