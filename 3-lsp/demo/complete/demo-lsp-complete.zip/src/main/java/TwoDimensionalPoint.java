public class TwoDimensionalPoint {
    private int lat;
    private int lon;

    public TwoDimensionalPoint(int lat, int lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public int getLat() {
        return lat;
    }

    public int getLon() {
        return lon;
    }
}
