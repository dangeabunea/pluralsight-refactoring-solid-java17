public interface PayPalPaymentService {
    void payUsingPayPal(double amount, String accountName);
}
