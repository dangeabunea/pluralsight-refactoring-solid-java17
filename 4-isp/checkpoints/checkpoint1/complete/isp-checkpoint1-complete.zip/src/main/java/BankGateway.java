public class BankGateway {
    public static void processCardPayment(double amount, String cardNumber, String ccv) {
        BankGateway.processCardPayment(amount, cardNumber, ccv);
    }

    public static void processBankPayment(double amount, String ibanCode) {
        BankGateway.processBankPayment(amount, ibanCode);
    }
}
