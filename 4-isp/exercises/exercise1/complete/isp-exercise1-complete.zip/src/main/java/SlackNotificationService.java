public interface SlackNotificationService {
    void sendSlackMessage(String slackUser, String text);
}
