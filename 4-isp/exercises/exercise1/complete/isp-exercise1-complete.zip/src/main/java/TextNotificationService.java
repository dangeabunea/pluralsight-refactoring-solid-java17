public interface TextNotificationService {
    void sendTextMessage(String phoneNb, String text);
}
