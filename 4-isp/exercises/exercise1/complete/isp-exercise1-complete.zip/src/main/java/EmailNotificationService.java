public interface EmailNotificationService {
    void sendEmail(String to, String text);
}
