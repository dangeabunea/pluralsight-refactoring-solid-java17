public interface InternalApplicationNotificationService {
    void sendInInternalApplication(String text);
}
