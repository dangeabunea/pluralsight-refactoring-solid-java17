public interface LabelWithMouseInteraction {
    void onFlightLabelClick();
    void onLabelDoubleClick();
}
