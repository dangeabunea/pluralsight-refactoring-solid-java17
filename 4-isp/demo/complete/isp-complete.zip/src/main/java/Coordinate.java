public record Coordinate(double lat, double lon, int alt) {
}
