public interface LabelWithTouchInteraction {
    void onLabelTouched();
}
