import java.util.List;

public interface AircraftLabel {
    String getDisplayValue();
    String getSelectedLabelColor();
}
