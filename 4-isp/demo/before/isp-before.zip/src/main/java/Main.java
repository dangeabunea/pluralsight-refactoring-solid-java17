import java.util.List;

import static java.lang.System.out;
import static java.util.List.of;

public class Main {
    public static void main(String[] args) {
    }
}
