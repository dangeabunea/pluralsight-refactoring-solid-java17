public enum ProductCategory {
    Food,
    Toys,
    Electronics,
    Household
}
