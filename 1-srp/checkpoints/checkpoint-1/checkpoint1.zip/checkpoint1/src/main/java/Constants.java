public class Constants {
    public static final int NM_TO_METER = 1852;
    public static final int FL_TO_FEET = 100;
    public static final double GALLON_TO_LITER = 4.54;
    public static final int MIN_PASSWORD_LENGTH = 12;
    public static final int NB_SPECIAL_CHARS_IN_PASSWORD = 1;
}
