import java.text.MessageFormat;

public class Program {
    public static void main(String[] args) {
    }
}
