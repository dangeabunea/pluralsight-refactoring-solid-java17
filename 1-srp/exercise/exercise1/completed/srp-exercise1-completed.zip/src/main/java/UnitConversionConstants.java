public class UnitConversionConstants {
    public static final int NM_TO_METER = 1852;
    public static final double GALLON_TO_LITER = 4.54;
}
