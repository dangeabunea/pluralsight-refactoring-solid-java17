public class PasswordConstants {
    public static final int MIN_PASSWORD_LENGTH = 12;
    public static final int NB_SPECIAL_CHARS_IN_PASSWORD = 1;
}
