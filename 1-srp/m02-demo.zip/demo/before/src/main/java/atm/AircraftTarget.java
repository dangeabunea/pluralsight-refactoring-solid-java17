package atm;

public record AircraftTarget(String id, int lat, int lon) {
}
